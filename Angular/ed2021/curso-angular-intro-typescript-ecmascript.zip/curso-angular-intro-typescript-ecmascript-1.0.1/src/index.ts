

console.log('Hola Mundo!');

/*
    ===== Código de TypeScript =====
*/

